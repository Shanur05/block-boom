// Haptic feedback controller for mobile browsers & APK PWA

class Haptics {
  private enabled: boolean = true;

  public setEnabled(val: boolean) {
    this.enabled = val;
  }

  public light() {
    if (!this.enabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      navigator.vibrate(12);
    } catch (_) {}
  }

  public medium() {
    if (!this.enabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      navigator.vibrate(28);
    } catch (_) {}
  }

  public heavy() {
    if (!this.enabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      navigator.vibrate([40, 30, 60]);
    } catch (_) {}
  }

  public success() {
    if (!this.enabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      navigator.vibrate([20, 40, 35, 40, 60]);
    } catch (_) {}
  }

  public danger() {
    if (!this.enabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      navigator.vibrate([80, 50, 100]);
    } catch (_) {}
  }
}

export const haptics = new Haptics();

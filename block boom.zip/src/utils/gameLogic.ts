import { CellData, Piece } from '../types';

export const BOARD_SIZE = 8;

const BASES: [number, string[]][] = [
  [0.6, ['#']],
  [2.0, ['##']],
  [2.0, ['###']],
  [1.6, ['####']],
  [1.0, ['#####']],
  [2.0, ['##', '##']],
  [1.0, ['###', '###', '###']],
  [1.6, ['###', '###']],
  [2.4, ['#.', '##']],
  [1.0, ['#..', '#..', '###']],
  [2.0, ['#.', '#.', '##']],
  [2.0, ['.#.', '###']],
  [1.4, ['##.', '.##']],
];

function toMatrix(rows: string[]): number[][] {
  return rows.map((s) => s.split('').map((ch) => (ch === '#' ? 1 : 0)));
}

export function rotateMatrix(m: number[][]): number[][] {
  const h = m.length;
  const w = m[0].length;
  const r: number[][] = [];
  for (let y = 0; y < w; y++) {
    r[y] = [];
    for (let x = 0; x < h; x++) {
      r[y][x] = m[h - 1 - x][y];
    }
  }
  return r;
}

function mirrorMatrix(m: number[][]): number[][] {
  return m.map((row) => row.slice().reverse());
}

function matrixKey(m: number[][]): string {
  return m.map((r) => r.join('')).join('/');
}

const GROUPS = BASES.map(([weight, raw]) => {
  const seen: Record<string, boolean> = {};
  const shapes: number[][][] = [];
  const base = toMatrix(raw);

  [base, mirrorMatrix(base)].forEach((variant) => {
    let curr = variant;
    for (let i = 0; i < 4; i++) {
      const k = matrixKey(curr);
      if (!seen[k]) {
        seen[k] = true;
        shapes.push(curr);
      }
      curr = rotateMatrix(curr);
    }
  });

  return { weight, shapes };
});

const TOTAL_WEIGHT = GROUPS.reduce((acc, g) => acc + g.weight, 0);

export function randPiece(): Piece {
  let r = Math.random() * TOTAL_WEIGHT;
  let selected = GROUPS[GROUPS.length - 1];

  for (let i = 0; i < GROUPS.length; i++) {
    r -= GROUPS[i].weight;
    if (r <= 0) {
      selected = GROUPS[i];
      break;
    }
  }

  const m = selected.shapes[Math.floor(Math.random() * selected.shapes.length)];
  let n = 0;
  m.forEach((row) => row.forEach((v) => { if (v) n += 1; }));

  return {
    id: 'p-' + Math.random().toString(36).substring(2, 9),
    m,
    w: m[0].length,
    h: m.length,
    n,
    color: 1 + Math.floor(Math.random() * 7),
  };
}

export function rotatePiece(p: Piece): Piece {
  const rm = rotateMatrix(p.m);
  return {
    ...p,
    m: rm,
    w: rm[0].length,
    h: rm.length,
  };
}

export function fits(
  grid: (CellData | null)[],
  m: number[][],
  r: number,
  c: number
): boolean {
  for (let y = 0; y < m.length; y++) {
    for (let x = 0; x < m[0].length; x++) {
      if (m[y][x]) {
        const yy = r + y;
        const xx = c + x;
        if (yy < 0 || xx < 0 || yy >= BOARD_SIZE || xx >= BOARD_SIZE) return false;
        if (grid[yy * BOARD_SIZE + xx] !== null) return false;
      }
    }
  }
  return true;
}

export function putPiece(
  grid: (CellData | null)[],
  p: Piece,
  r: number,
  c: number,
  bombCoord?: { r: number; c: number; count: number }
): (CellData | null)[] {
  const out = [...grid];
  for (let y = 0; y < p.h; y++) {
    for (let x = 0; x < p.w; x++) {
      if (p.m[y][x]) {
        const idx = (r + y) * BOARD_SIZE + c + x;
        const isThisBomb = bombCoord && bombCoord.r === r + y && bombCoord.c === c + x;
        out[idx] = {
          color: p.color,
          isBomb: Boolean(isThisBomb),
          bombCountdown: isThisBomb ? bombCoord.count : undefined,
        };
      }
    }
  }
  return out;
}

export function findFullLines(grid: (CellData | null)[]): {
  rows: number[];
  cols: number[];
  total: number;
} {
  const rows: number[] = [];
  const cols: number[] = [];

  for (let i = 0; i < BOARD_SIZE; i++) {
    let full = true;
    for (let j = 0; j < BOARD_SIZE; j++) {
      if (grid[i * BOARD_SIZE + j] === null) {
        full = false;
        break;
      }
    }
    if (full) rows.push(i);
  }

  for (let j = 0; j < BOARD_SIZE; j++) {
    let full = true;
    for (let i = 0; i < BOARD_SIZE; i++) {
      if (grid[i * BOARD_SIZE + j] === null) {
        full = false;
        break;
      }
    }
    if (full) cols.push(j);
  }

  return { rows, cols, total: rows.length + cols.length };
}

export function getLineCellIndices(lines: { rows: number[]; cols: number[] }): number[] {
  const seen: Record<number, boolean> = {};
  const out: number[] = [];

  const add = (idx: number) => {
    if (!seen[idx]) {
      seen[idx] = true;
      out.push(idx);
    }
  };

  lines.rows.forEach((r) => {
    for (let j = 0; j < BOARD_SIZE; j++) add(r * BOARD_SIZE + j);
  });
  lines.cols.forEach((c) => {
    for (let i = 0; i < BOARD_SIZE; i++) add(i * BOARD_SIZE + c);
  });

  return out;
}

export function anyFit(grid: (CellData | null)[], m: number[][]): boolean {
  for (let r = 0; r <= BOARD_SIZE - m.length; r++) {
    for (let c = 0; c <= BOARD_SIZE - m[0].length; c++) {
      if (fits(grid, m, r, c)) return true;
    }
  }
  return false;
}

function simulateClear(grid: (CellData | null)[]): (CellData | null)[] {
  const lines = findFullLines(grid);
  if (lines.total === 0) return grid;
  const cells = getLineCellIndices(lines);
  const next = [...grid];
  cells.forEach((idx) => {
    next[idx] = null;
  });
  return next;
}

export function isSolvable(grid: (CellData | null)[], matrices: number[][][]): boolean {
  if (matrices.length === 0) return true;

  for (let i = 0; i < matrices.length; i++) {
    const m = matrices[i];
    const rest = matrices.filter((_, k) => k !== i);

    for (let r = 0; r <= BOARD_SIZE - m.length; r++) {
      for (let c = 0; c <= BOARD_SIZE - m[0].length; c++) {
        if (fits(grid, m, r, c)) {
          // create hypothetical board
          const nextGrid = [...grid];
          for (let y = 0; y < m.length; y++) {
            for (let x = 0; x < m[0].length; x++) {
              if (m[y][x]) nextGrid[(r + y) * BOARD_SIZE + c + x] = { color: 1 };
            }
          }
          const cleared = simulateClear(nextGrid);
          if (isSolvable(cleared, rest)) return true;
        }
      }
    }
  }
  return false;
}

export function generatePieceSet(grid: (CellData | null)[]): (Piece | null)[] {
  let fallback: (Piece | null)[] | null = null;

  for (let attempt = 0; attempt < 35; attempt++) {
    const set = [randPiece(), randPiece(), randPiece()];
    if (isSolvable(grid, set.map((p) => p.m))) {
      return set;
    }
    if (!fallback && set.some((p) => anyFit(grid, p.m))) {
      fallback = set;
    }
  }

  return fallback || [randPiece(), randPiece(), randPiece()];
}

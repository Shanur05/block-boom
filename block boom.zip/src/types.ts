export type GameMode = 'classic' | 'time' | 'bomb';

export type ThemeId = 'neon' | 'wood' | 'cyberpunk' | 'emerald';

export interface Piece {
  id: string;
  m: number[][]; // 2D matrix 0 or 1
  w: number;
  h: number;
  n: number; // total filled squares
  color: number; // 1 to 7
}

export interface CellData {
  color: number;
  isBomb?: boolean;
  bombCountdown?: number;
}

export interface DragState {
  pieceIndex: number;
  piece: Piece;
  startClientX: number;
  startClientY: number;
  currentClientX: number;
  currentClientY: number;
  hoverSpot: { r: number; c: number } | null;
}

export interface FloatingPop {
  id: string;
  text: string;
  x: number;
  y: number;
  isBig?: boolean;
  color?: string;
}

export interface GameStats {
  gamesPlayed: number;
  linesCleared: number;
  highestStreak: number;
  bestScores: Record<GameMode, number>;
}

export interface UserSettings {
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  theme: ThemeId;
}

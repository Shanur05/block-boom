import React, { useRef } from 'react';
import { CellData, Piece } from '../types';
import { anyFit, BOARD_SIZE, fits } from '../utils/gameLogic';
import { soundEffects } from '../utils/audio';
import { haptics } from '../utils/haptics';

interface PieceTrayProps {
  pieces: (Piece | null)[];
  grid: (CellData | null)[];
  isRotatingMode: boolean;
  onRotatePiece: (index: number) => void;
  onStartDrag: (index: number, piece: Piece, clientX: number, clientY: number) => void;
  onUpdateDrag: (clientX: number, clientY: number, hoverSpot: { r: number; c: number } | null) => void;
  onEndDrag: (placedSpot: { r: number; c: number } | null) => void;
  activeDragIndex: number | null;
}

export const PieceTray: React.FC<PieceTrayProps> = ({
  pieces,
  grid,
  isRotatingMode,
  onRotatePiece,
  onStartDrag,
  onUpdateDrag,
  onEndDrag,
  activeDragIndex,
}) => {
  const currentDragRef = useRef<{
    index: number;
    piece: Piece;
    boardRect: DOMRect | null;
    cellPitch: number;
    lastHoverSpot: { r: number; c: number } | null;
  } | null>(null);

  const calculateSpotFromPointer = (
    clientX: number,
    clientY: number,
    piece: Piece
  ): { r: number; c: number } | null => {
    const boardEl = document.getElementById('game-board-container');
    if (!boardEl) return null;

    const rect = boardEl.getBoundingClientRect();
    // Inner grid padding is ~8px
    const pad = 12;
    const gridWidth = rect.width - pad * 2;
    const cellPitch = gridWidth / BOARD_SIZE;

    // Mobile finger elevation offset: elevate piece above touch point
    const offsetY = cellPitch * 1.35;
    const effectiveX = clientX;
    const effectiveY = clientY - offsetY;

    // Piece center offset
    const pieceCenterX = (piece.w * cellPitch) / 2;
    const pieceCenterY = (piece.h * cellPitch) / 2;

    const leftX = effectiveX - pieceCenterX;
    const topY = effectiveY - pieceCenterY;

    const colFloat = (leftX - (rect.left + pad)) / cellPitch;
    const rowFloat = (topY - (rect.top + pad)) / cellPitch;

    const r0 = Math.round(rowFloat);
    const c0 = Math.round(colFloat);

    let bestSpot: { r: number; c: number } | null = null;
    let minDistance = 0.95; // Snap tolerance in cell units

    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        const candidateR = r0 + dr;
        const candidateC = c0 + dc;
        if (fits(grid, piece.m, candidateR, candidateC)) {
          const dist = Math.hypot(candidateR - rowFloat, candidateC - colFloat);
          if (dist < minDistance) {
            minDistance = dist;
            bestSpot = { r: candidateR, c: candidateC };
          }
        }
      }
    }

    return bestSpot;
  };

  const handlePointerDown = (index: number, piece: Piece, e: React.PointerEvent<HTMLDivElement>) => {
    if (isRotatingMode) {
      soundEffects.playPowerUp();
      haptics.medium();
      onRotatePiece(index);
      return;
    }

    if (e.button !== 0 && e.pointerType === 'mouse') return;
    e.preventDefault();

    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch (_) {}

    soundEffects.playPickUp();
    haptics.light();

    const spot = calculateSpotFromPointer(e.clientX, e.clientY, piece);
    currentDragRef.current = {
      index,
      piece,
      boardRect: null,
      cellPitch: 0,
      lastHoverSpot: spot,
    };

    onStartDrag(index, piece, e.clientX, e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!currentDragRef.current) return;
    e.preventDefault();

    const { piece } = currentDragRef.current;
    const spot = calculateSpotFromPointer(e.clientX, e.clientY, piece);
    currentDragRef.current.lastHoverSpot = spot;

    onUpdateDrag(e.clientX, e.clientY, spot);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!currentDragRef.current) return;
    e.preventDefault();

    const finalSpot = currentDragRef.current.lastHoverSpot;
    currentDragRef.current = null;

    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (_) {}

    onEndDrag(finalSpot);
  };

  const handlePointerCancel = () => {
    if (!currentDragRef.current) return;
    currentDragRef.current = null;
    onEndDrag(null);
  };

  return (
    <div className="w-full max-w-[440px] grid grid-cols-3 gap-2.5 h-[110px] items-stretch">
      {pieces.map((piece, i) => {
        const isDead = piece ? !anyFit(grid, piece.m) : false;
        const isLifted = activeDragIndex === i;

        return (
          <div
            key={i}
            onPointerDown={(e) => piece && handlePointerDown(i, piece, e)}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={handlePointerCancel}
            className={`relative flex items-center justify-center rounded-2xl bg-[#161923] border border-[#2b3144] p-2 select-none touch-none transition-all duration-150 ${
              piece && !isLifted ? 'cursor-grab active:cursor-grabbing hover:border-[#ffb020]/40' : ''
            } ${isDead ? 'opacity-35 grayscale' : ''} ${
              isLifted ? 'opacity-20' : ''
            } ${isRotatingMode && piece ? 'ring-2 ring-[#ffb020] animate-pulse cursor-pointer' : ''}`}
          >
            {piece && (
              <div
                className={`grid gap-1 transition-transform pointer-events-none piece-enter t${piece.color}`}
                style={{
                  gridTemplateColumns: `repeat(${piece.w}, minmax(0, 1fr))`,
                  width: `${piece.w * 22}px`,
                  height: `${piece.h * 22}px`,
                }}
              >
                {piece.m.map((row, rIdx) =>
                  row.map((val, cIdx) => (
                    <div
                      key={`${rIdx}-${cIdx}`}
                      className={`w-[20px] h-[20px] rounded-md ${
                        val ? 'cell-filled' : 'opacity-0'
                      }`}
                    />
                  ))
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

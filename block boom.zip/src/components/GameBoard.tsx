import React, { useMemo } from 'react';
import { CellData, FloatingPop, Piece } from '../types';
import { BOARD_SIZE, findFullLines, getLineCellIndices, putPiece } from '../utils/gameLogic';

interface GameBoardProps {
  grid: (CellData | null)[];
  boomingCells: Set<number>;
  hoverSpot: { r: number; c: number } | null;
  draggedPiece: Piece | null;
  floatingPops: FloatingPop[];
  isShaking: boolean;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  grid,
  boomingCells,
  hoverSpot,
  draggedPiece,
  floatingPops,
  isShaking,
}) => {
  // Compute ghost placement cells & prospective cleared lines
  const { ghostIndices, previewClearIndices } = useMemo(() => {
    const ghost = new Set<number>();
    const clear = new Set<number>();

    if (hoverSpot && draggedPiece) {
      // Collect ghost indices
      for (let y = 0; y < draggedPiece.h; y++) {
        for (let x = 0; x < draggedPiece.w; x++) {
          if (draggedPiece.m[y][x]) {
            const idx = (hoverSpot.r + y) * BOARD_SIZE + hoverSpot.c + x;
            ghost.add(idx);
          }
        }
      }

      // Simulate placement to see which rows/cols will clear
      const hypothetical = putPiece(grid, draggedPiece, hoverSpot.r, hoverSpot.c);
      const lines = findFullLines(hypothetical);
      if (lines.total > 0) {
        getLineCellIndices(lines).forEach((idx) => clear.add(idx));
      }
    }

    return { ghostIndices: ghost, previewClearIndices: clear };
  }, [hoverSpot, draggedPiece, grid]);

  return (
    <div
      id="game-board-container"
      className={`relative w-full max-w-[440px] aspect-square p-2 bg-[#161923] border border-[#2b3144] rounded-2xl shadow-xl transition-transform ${
        isShaking ? 'shake' : ''
      }`}
    >
      <div className="w-full h-full grid grid-cols-8 grid-rows-8 gap-1.5 p-1 rounded-xl bg-[#0e1016]/40">
        {grid.map((cell, idx) => {
          const isBooming = boomingCells.has(idx);
          const isGhost = ghostIndices.has(idx);
          const isPreviewClear = previewClearIndices.has(idx);

          let cellClass =
            'relative flex items-center justify-center rounded-lg transition-colors duration-150 overflow-hidden';

          if (isBooming) {
            cellClass += ` cell-boom ${cell ? `t${cell.color} cell-filled` : ''}`;
          } else if (cell) {
            cellClass += ` cell-filled t${cell.color}`;
          } else if (isGhost && draggedPiece) {
            cellClass += ` cell-ghost t${draggedPiece.color}`;
          } else {
            cellClass += ' bg-[#212635]/80 border border-[#2b3144]/40';
          }

          if (isPreviewClear) {
            cellClass += ' cell-preview-clear';
          }

          return (
            <div key={idx} className={cellClass} data-index={idx}>
              {/* Bomb Indicator Badge */}
              {cell?.isBomb && (
                <div
                  className={`flex items-center justify-center w-full h-full font-mono font-bold text-xs ${
                    (cell.bombCountdown ?? 0) <= 3
                      ? 'text-white bg-red-600/80 bomb-pulse'
                      : 'text-white bg-black/50'
                  }`}
                >
                  <span className="text-[10px] mr-0.5">💣</span>
                  <span>{cell.bombCountdown}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Floating score & combo popups */}
      {floatingPops.map((pop) => (
        <div
          key={pop.id}
          className={`pop-text absolute z-30 font-extrabold select-none ${
            pop.isBig
              ? 'text-2xl text-[#ffb020] drop-shadow-[0_2px_12px_rgba(255,176,32,0.8)]'
              : 'text-lg text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]'
          }`}
          style={{
            left: `${pop.x}px`,
            top: `${pop.y}px`,
            color: pop.color,
          }}
        >
          {pop.text}
        </div>
      ))}
    </div>
  );
};

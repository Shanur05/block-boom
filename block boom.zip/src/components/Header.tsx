import React from 'react';
import { Settings, RotateCw, Shuffle, Undo2, Smartphone, Clock, Flame, ShieldAlert, Pause } from 'lucide-react';
import { GameMode } from '../types';
import { soundEffects } from '../utils/audio';

interface HeaderProps {
  score: number;
  bestScore: number;
  mode: GameMode;
  timeLeft: number;
  onOpenSettings: () => void;
  onOpenInstall: () => void;
  onPause: () => void;
  // Boosters
  rotateUses: number;
  rerollUses: number;
  undoUses: number;
  canUndo: boolean;
  onRotateActive: () => void;
  isRotating: boolean;
  onReroll: () => void;
  onUndo: () => void;
  streak: number;
}

export const Header: React.FC<HeaderProps> = ({
  score,
  bestScore,
  mode,
  timeLeft,
  onOpenSettings,
  onOpenInstall,
  onPause,
  rotateUses,
  rerollUses,
  undoUses,
  canUndo,
  onRotateActive,
  isRotating,
  onReroll,
  onUndo,
  streak,
}) => {
  return (
    <header className="w-full max-w-[440px] flex flex-col gap-2 pt-2 px-1">
      {/* Top Bar: Title, Mode badge, Action buttons */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-[#ffb020] to-[#ff6b57] bg-clip-text text-transparent">
            БЛОК БУМ
          </h1>
          <span className="px-2 py-0.5 rounded-md text-[10px] font-mono uppercase tracking-wider bg-[#212635] text-[#8a91a7] border border-[#2b3144] flex items-center gap-1">
            {mode === 'classic' && <span>Классика</span>}
            {mode === 'time' && (
              <>
                <Clock size={11} className="text-[#4da3ff]" />
                <span className="text-[#4da3ff]">Таймер</span>
              </>
            )}
            {mode === 'bomb' && (
              <>
                <ShieldAlert size={11} className="text-[#ff6b57]" />
                <span className="text-[#ff6b57]">Бомбы</span>
              </>
            )}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              soundEffects.playTap();
              onOpenInstall();
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#212635] hover:bg-[#2b3144] text-[#ffb020] text-xs font-semibold border border-[#ffb020]/30 transition active:scale-95 shadow-sm"
            title="Установить APK / PWA"
          >
            <Smartphone size={13} />
            <span className="hidden sm:inline">APK</span>
          </button>

          <button
            onClick={() => {
              soundEffects.playTap();
              onPause();
            }}
            className="p-1.5 rounded-lg bg-[#212635] hover:bg-[#2b3144] text-[#8a91a7] hover:text-[#eef0f6] border border-[#2b3144] transition active:scale-95"
            title="Пауза"
            aria-label="Пауза"
          >
            <Pause size={16} />
          </button>

          <button
            onClick={() => {
              soundEffects.playTap();
              onOpenSettings();
            }}
            className="p-1.5 rounded-lg bg-[#212635] hover:bg-[#2b3144] text-[#8a91a7] hover:text-[#eef0f6] border border-[#2b3144] transition active:scale-95"
            title="Настройки"
            aria-label="Настройки"
          >
            <Settings size={16} />
          </button>
        </div>
      </div>

      {/* Score and Streak Dashboard */}
      <div className="grid grid-cols-2 gap-2 bg-[#161923] p-2.5 rounded-xl border border-[#2b3144]">
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="font-mono text-[10px] uppercase tracking-wider text-[#8a91a7]">
              СЧЁТ
            </span>
            {streak >= 2 && (
              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-[#ffb020]/20 text-[#ffb020] animate-pulse">
                <Flame size={10} />
                x{streak}
              </span>
            )}
          </div>
          <div className="text-3xl font-extrabold tracking-tight leading-none tabular-nums text-[#eef0f6] mt-0.5">
            {score}
          </div>
        </div>

        <div className="flex flex-col items-end justify-between">
          <span className="font-mono text-[10px] uppercase tracking-wider text-[#8a91a7]">
            РЕКОРД
          </span>
          <div className="text-2xl font-extrabold tracking-tight leading-none tabular-nums text-[#ffb020] mt-0.5">
            {bestScore}
          </div>
        </div>
      </div>

      {/* Time Mode Countdown Bar */}
      {mode === 'time' && (
        <div className="w-full bg-[#161923] rounded-lg p-1.5 border border-[#2b3144] flex items-center gap-2">
          <Clock size={14} className={timeLeft <= 15 ? 'text-[#ff6b57] animate-pulse' : 'text-[#4da3ff]'} />
          <div className="flex-1 h-2 rounded-full bg-[#212635] overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                timeLeft <= 15 ? 'bg-[#ff6b57]' : timeLeft <= 30 ? 'bg-[#ffb020]' : 'bg-[#4da3ff]'
              }`}
              style={{ width: `${Math.min(100, (timeLeft / 90) * 100)}%` }}
            />
          </div>
          <span
            className={`font-mono text-xs font-bold tabular-nums ${
              timeLeft <= 15 ? 'text-[#ff6b57] animate-pulse' : 'text-[#eef0f6]'
            }`}
          >
            {timeLeft}с
          </span>
        </div>
      )}

      {/* Boosters / Power-ups Bar */}
      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={onRotateActive}
          disabled={rotateUses <= 0}
          className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg border text-xs font-medium transition active:scale-95 ${
            isRotating
              ? 'bg-[#ffb020] text-black border-[#ffb020] font-bold shadow-md shadow-[#ffb020]/30 animate-pulse'
              : rotateUses > 0
              ? 'bg-[#212635] hover:bg-[#2b3144] text-[#eef0f6] border-[#2b3144]'
              : 'bg-[#161923] text-[#8a91a7]/40 border-transparent cursor-not-allowed'
          }`}
          title="Повернуть фигуру в лотке"
        >
          <RotateCw size={13} className={isRotating ? 'animate-spin' : ''} />
          <span>Поворот</span>
          <span className="text-[10px] font-mono px-1 rounded bg-black/30">{rotateUses}</span>
        </button>

        <button
          onClick={onReroll}
          disabled={rerollUses <= 0}
          className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg border text-xs font-medium transition active:scale-95 ${
            rerollUses > 0
              ? 'bg-[#212635] hover:bg-[#2b3144] text-[#eef0f6] border-[#2b3144]'
              : 'bg-[#161923] text-[#8a91a7]/40 border-transparent cursor-not-allowed'
          }`}
          title="Сменить 3 фигуры в лотке"
        >
          <Shuffle size={13} />
          <span>Смена</span>
          <span className="text-[10px] font-mono px-1 rounded bg-black/30">{rerollUses}</span>
        </button>

        <button
          onClick={onUndo}
          disabled={undoUses <= 0 || !canUndo}
          className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg border text-xs font-medium transition active:scale-95 ${
            undoUses > 0 && canUndo
              ? 'bg-[#212635] hover:bg-[#2b3144] text-[#eef0f6] border-[#2b3144]'
              : 'bg-[#161923] text-[#8a91a7]/40 border-transparent cursor-not-allowed'
          }`}
          title="Отменить последний ход"
        >
          <Undo2 size={13} />
          <span>Отмена</span>
          <span className="text-[10px] font-mono px-1 rounded bg-black/30">{undoUses}</span>
        </button>
      </div>
    </header>
  );
};

import React, { useState } from 'react';
import { Volume2, VolumeX, Vibrate, Palette, BarChart2, BookOpen, X, RefreshCw } from 'lucide-react';
import { GameMode, GameStats, ThemeId, UserSettings } from '../types';
import { soundEffects } from '../utils/audio';
import { haptics } from '../utils/haptics';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  stats: GameStats;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  onResetStats: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  stats,
  onUpdateSettings,
  onResetStats,
}) => {
  const [tab, setTab] = useState<'settings' | 'stats' | 'rules'>('settings');

  if (!isOpen) return null;

  const themes: { id: ThemeId; name: string; bg: string; dot: string }[] = [
    { id: 'neon', name: 'Тёмный Неон', bg: '#0e1016', dot: '#ffb020' },
    { id: 'wood', name: 'Дерево & Золото', bg: '#1c1512', dot: '#e59837' },
    { id: 'cyberpunk', name: 'Киберпанк', bg: '#0a0612', dot: '#00f2fe' },
    { id: 'emerald', name: 'Изумруд', bg: '#081410', dot: '#2ecc71' },
  ];

  const handleSoundToggle = () => {
    const next = !settings.soundEnabled;
    onUpdateSettings({ soundEnabled: next });
    soundEffects.setEnabled(next);
    if (next) soundEffects.playPickUp();
  };

  const handleVibrateToggle = () => {
    const next = !settings.vibrationEnabled;
    onUpdateSettings({ vibrationEnabled: next });
    haptics.setEnabled(next);
    if (next) haptics.medium();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-2xl bg-[#161923] border border-[#2b3144] p-5 shadow-2xl text-[#eef0f6] relative flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#2b3144]">
          <h3 className="text-lg font-bold">Настройки и Инфо</h3>
          <button
            onClick={() => {
              soundEffects.playTap();
              onClose();
            }}
            className="text-[#8a91a7] hover:text-[#eef0f6] p-1 rounded-lg"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-3 gap-1.5 my-3 p-1 rounded-xl bg-[#212635] text-xs font-medium">
          <button
            onClick={() => { soundEffects.playTap(); setTab('settings'); }}
            className={`py-1.5 rounded-lg transition ${
              tab === 'settings' ? 'bg-[#ffb020] text-black font-bold shadow' : 'text-[#8a91a7]'
            }`}
          >
            Опции
          </button>
          <button
            onClick={() => { soundEffects.playTap(); setTab('stats'); }}
            className={`py-1.5 rounded-lg transition ${
              tab === 'stats' ? 'bg-[#ffb020] text-black font-bold shadow' : 'text-[#8a91a7]'
            }`}
          >
            Статистика
          </button>
          <button
            onClick={() => { soundEffects.playTap(); setTab('rules'); }}
            className={`py-1.5 rounded-lg transition ${
              tab === 'rules' ? 'bg-[#ffb020] text-black font-bold shadow' : 'text-[#8a91a7]'
            }`}
          >
            Правила
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto pr-1 flex-1 space-y-4 py-1">
          {tab === 'settings' && (
            <div className="space-y-4">
              {/* Sound Toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#212635]/60 border border-[#2b3144]">
                <div className="flex items-center gap-2.5">
                  {settings.soundEnabled ? (
                    <Volume2 className="text-[#ffb020]" size={18} />
                  ) : (
                    <VolumeX className="text-[#8a91a7]" size={18} />
                  )}
                  <span className="text-sm font-medium">Звуковые эффекты</span>
                </div>
                <button
                  onClick={handleSoundToggle}
                  className={`w-12 h-6 rounded-full transition-colors p-0.5 flex items-center ${
                    settings.soundEnabled ? 'bg-[#ffb020] justify-end' : 'bg-[#2b3144] justify-start'
                  }`}
                >
                  <div className="w-5 h-5 rounded-full bg-black shadow" />
                </button>
              </div>

              {/* Vibration Toggle */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#212635]/60 border border-[#2b3144]">
                <div className="flex items-center gap-2.5">
                  <Vibrate className={settings.vibrationEnabled ? 'text-[#ffb020]' : 'text-[#8a91a7]'} size={18} />
                  <span className="text-sm font-medium">Вибрация (Haptics)</span>
                </div>
                <button
                  onClick={handleVibrateToggle}
                  className={`w-12 h-6 rounded-full transition-colors p-0.5 flex items-center ${
                    settings.vibrationEnabled ? 'bg-[#ffb020] justify-end' : 'bg-[#2b3144] justify-start'
                  }`}
                >
                  <div className="w-5 h-5 rounded-full bg-black shadow" />
                </button>
              </div>

              {/* Theme Chooser */}
              <div>
                <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#8a91a7] mb-2">
                  <Palette size={14} />
                  <span>Тема оформления</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {themes.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => {
                        soundEffects.playTap();
                        onUpdateSettings({ theme: t.id });
                      }}
                      className={`flex items-center gap-2 p-2.5 rounded-xl border text-left text-xs font-medium transition ${
                        settings.theme === t.id
                          ? 'border-[#ffb020] bg-[#212635] text-[#ffb020]'
                          : 'border-[#2b3144] bg-[#212635]/30 text-[#8a91a7] hover:border-[#8a91a7]'
                      }`}
                    >
                      <span
                        className="w-4 h-4 rounded-full border border-white/20 shrink-0"
                        style={{ backgroundColor: t.dot }}
                      />
                      <span>{t.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {tab === 'stats' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 rounded-xl bg-[#212635]/60 border border-[#2b3144]">
                  <span className="text-[10px] font-mono text-[#8a91a7] uppercase">Игр сыграно</span>
                  <div className="text-xl font-bold mt-0.5">{stats.gamesPlayed}</div>
                </div>
                <div className="p-3 rounded-xl bg-[#212635]/60 border border-[#2b3144]">
                  <span className="text-[10px] font-mono text-[#8a91a7] uppercase">Линий очищено</span>
                  <div className="text-xl font-bold mt-0.5">{stats.linesCleared}</div>
                </div>
                <div className="p-3 rounded-xl bg-[#212635]/60 border border-[#2b3144]">
                  <span className="text-[10px] font-mono text-[#8a91a7] uppercase">Макс. комбо</span>
                  <div className="text-xl font-bold text-[#ffb020] mt-0.5">x{stats.highestStreak}</div>
                </div>
                <div className="p-3 rounded-xl bg-[#212635]/60 border border-[#2b3144]">
                  <span className="text-[10px] font-mono text-[#8a91a7] uppercase">Рекорд (Классика)</span>
                  <div className="text-xl font-bold text-[#ffb020] mt-0.5">{stats.bestScores.classic}</div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#212635]/40 border border-[#2b3144] space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-[#8a91a7]">На время (90 сек):</span>
                  <span className="font-mono font-bold">{stats.bestScores.time}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#8a91a7]">Бомбы:</span>
                  <span className="font-mono font-bold">{stats.bestScores.bomb}</span>
                </div>
              </div>

              <button
                onClick={() => {
                  if (confirm('Сбросить всю статистику и рекорды?')) {
                    onResetStats();
                    soundEffects.playTap();
                  }
                }}
                className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs text-red-400 hover:bg-red-500/10 transition border border-red-500/20"
              >
                <RefreshCw size={12} />
                <span>Сбросить рекорды</span>
              </button>
            </div>
          )}

          {tab === 'rules' && (
            <div className="space-y-3 text-xs text-[#8a91a7] leading-relaxed">
              <div className="p-3 rounded-xl bg-[#212635]/60 border border-[#2b3144]">
                <h4 className="font-bold text-[#eef0f6] mb-1">🎮 Как играть:</h4>
                <p>Перетаскивайте блоки из нижнего лотка на поле 8x8. Заполняйте целые горизонтальные строки или вертикальные столбцы, чтобы они исчезали!</p>
              </div>

              <div className="p-3 rounded-xl bg-[#212635]/60 border border-[#2b3144]">
                <h4 className="font-bold text-[#ffb020] mb-1">🔥 Комбо-стрик:</h4>
                <p>Очищайте линии несколько ходов подряд, чтобы накапливать комбо-множитель и получать огромные очки!</p>
              </div>

              <div className="p-3 rounded-xl bg-[#212635]/60 border border-[#2b3144]">
                <h4 className="font-bold text-[#4da3ff] mb-1">✨ Чистое поле (+150):</h4>
                <p>Если удастся полностью освободить всё поле от блоков, вы получите бонус «Чисто!» в 150 очков!</p>
              </div>

              <div className="p-3 rounded-xl bg-[#212635]/60 border border-[#2b3144]">
                <h4 className="font-bold text-[#ff6b57] mb-1">💣 Режим бомб:</h4>
                <p>В режиме «Бомбы» на поле появляются блоки с таймером обратного отсчёта. Очищайте линию с бомбой, пока счётчик не дошёл до нуля!</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <button
          onClick={() => {
            soundEffects.playTap();
            onClose();
          }}
          className="mt-4 w-full py-2.5 rounded-xl bg-[#ffb020] text-black font-bold text-xs hover:brightness-110 active:scale-95 transition"
        >
          Готово
        </button>
      </div>
    </div>
  );
};

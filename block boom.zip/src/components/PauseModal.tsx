import React from 'react';
import { Play, RotateCcw, Settings, X, Smartphone } from 'lucide-react';
import { GameMode } from '../types';
import { soundEffects } from '../utils/audio';

interface PauseModalProps {
  isOpen: boolean;
  onResume: () => void;
  onRestart: () => void;
  mode: GameMode;
  onChangeMode: (mode: GameMode) => void;
  onOpenSettings: () => void;
  onOpenInstall: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  isOpen,
  onResume,
  onRestart,
  mode,
  onChangeMode,
  onOpenSettings,
  onOpenInstall,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-xs rounded-2xl bg-[#161923] border border-[#2b3144] p-5 shadow-2xl text-[#eef0f6] text-center relative">
        <button
          onClick={() => {
            soundEffects.playTap();
            onResume();
          }}
          className="absolute top-4 right-4 text-[#8a91a7] hover:text-[#eef0f6] p-1 rounded-lg"
        >
          <X size={18} />
        </button>

        <h3 className="text-xl font-black mb-4">ПАУЗА</h3>

        <div className="space-y-2">
          <button
            onClick={() => {
              soundEffects.playTap();
              onResume();
            }}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-[#ffb020] text-black font-extrabold text-sm hover:brightness-110 active:scale-95 transition"
          >
            <Play size={16} fill="currentColor" />
            <span>Продолжить</span>
          </button>

          <button
            onClick={() => {
              soundEffects.playTap();
              onRestart();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#212635] hover:bg-[#2b3144] text-[#eef0f6] font-semibold text-xs border border-[#2b3144] transition"
          >
            <RotateCcw size={14} />
            <span>Начать заново</span>
          </button>

          <div className="pt-2">
            <span className="text-[10px] font-mono text-[#8a91a7] uppercase tracking-wider block mb-1.5">
              Сменить режим игры
            </span>
            <div className="grid grid-cols-3 gap-1">
              <button
                onClick={() => {
                  soundEffects.playTap();
                  onChangeMode('classic');
                }}
                className={`py-1.5 rounded-lg text-xs font-medium border transition ${
                  mode === 'classic'
                    ? 'border-[#ffb020] bg-[#212635] text-[#ffb020]'
                    : 'border-[#2b3144] bg-[#212635]/40 text-[#8a91a7]'
                }`}
              >
                Классика
              </button>
              <button
                onClick={() => {
                  soundEffects.playTap();
                  onChangeMode('time');
                }}
                className={`py-1.5 rounded-lg text-xs font-medium border transition ${
                  mode === 'time'
                    ? 'border-[#4da3ff] bg-[#212635] text-[#4da3ff]'
                    : 'border-[#2b3144] bg-[#212635]/40 text-[#8a91a7]'
                }`}
              >
                На время
              </button>
              <button
                onClick={() => {
                  soundEffects.playTap();
                  onChangeMode('bomb');
                }}
                className={`py-1.5 rounded-lg text-xs font-medium border transition ${
                  mode === 'bomb'
                    ? 'border-[#ff6b57] bg-[#212635] text-[#ff6b57]'
                    : 'border-[#2b3144] bg-[#212635]/40 text-[#8a91a7]'
                }`}
              >
                Бомбы
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-1.5 pt-2">
            <button
              onClick={() => {
                soundEffects.playTap();
                onOpenSettings();
              }}
              className="flex items-center justify-center gap-1.5 py-2 rounded-xl bg-[#212635] text-[#8a91a7] hover:text-[#eef0f6] text-xs border border-[#2b3144]"
            >
              <Settings size={13} />
              <span>Опции</span>
            </button>
            <button
              onClick={() => {
                soundEffects.playTap();
                onOpenInstall();
              }}
              className="flex items-center justify-center gap-1.5 py-2 rounded-xl bg-[#212635] text-[#ffb020] text-xs border border-[#2b3144]"
            >
              <Smartphone size={13} />
              <span>APK инфо</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

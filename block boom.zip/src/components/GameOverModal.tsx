import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Trophy, Smartphone, Flame } from 'lucide-react';
import { GameMode } from '../types';
import { soundEffects } from '../utils/audio';

interface GameOverModalProps {
  isOpen: boolean;
  score: number;
  bestScore: number;
  isNewRecord: boolean;
  reason: 'no_moves' | 'bomb_exploded' | 'time_out';
  mode: GameMode;
  onRestart: () => void;
  onChangeMode: (mode: GameMode) => void;
  onOpenInstall: () => void;
  isInstalled: boolean;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  isOpen,
  score,
  bestScore,
  isNewRecord,
  reason,
  mode,
  onRestart,
  onChangeMode,
  onOpenInstall,
  isInstalled,
}) => {
  useEffect(() => {
    if (isOpen && isNewRecord) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#ffb020', '#ff6b57', '#2ec4b6', '#a07bff', '#ffffff'],
        });
      } catch (_) {}
    }
  }, [isOpen, isNewRecord]);

  if (!isOpen) return null;

  let title = 'Места нет!';
  if (reason === 'bomb_exploded') title = '💥 Бомба взорвалась!';
  if (reason === 'time_out') title = '⏰ Время вышло!';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-2xl bg-[#161923] border border-[#2b3144] p-6 shadow-2xl text-[#eef0f6] text-center relative">
        {isNewRecord && (
          <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#ffb020]/20 text-[#ffb020] text-xs font-bold border border-[#ffb020]/40 mb-3 animate-bounce">
            <Trophy size={14} />
            <span>НОВЫЙ РЕКОРД!</span>
          </div>
        )}

        <h2 className="text-2xl font-black tracking-tight mb-2">{title}</h2>

        <div className="my-4 p-4 rounded-xl bg-[#212635]/80 border border-[#2b3144]">
          <span className="text-[11px] font-mono text-[#8a91a7] uppercase tracking-wider">
            ИТОГОВЫЙ СЧЁТ
          </span>
          <div className="text-5xl font-extrabold tracking-tight text-[#eef0f6] my-1 tabular-nums">
            {score}
          </div>
          <p className="text-xs font-mono text-[#8a91a7]">
            {isNewRecord ? (
              <span className="text-[#ffb020] font-bold">Вы превзошли прошлый рекорд!</span>
            ) : (
              `РЕКОРД: ${bestScore}`
            )}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 mt-4">
          <button
            onClick={() => {
              soundEffects.playTap();
              onRestart();
            }}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#ffb020] text-black font-extrabold text-sm hover:brightness-110 active:scale-95 transition shadow-lg shadow-[#ffb020]/20"
          >
            <RotateCcw size={18} />
            <span>Играть снова</span>
          </button>

          {/* Mode Switchers */}
          <div className="grid grid-cols-3 gap-1.5 pt-1">
            <button
              onClick={() => { soundEffects.playTap(); onChangeMode('classic'); }}
              className={`py-1.5 rounded-lg text-xs font-medium border transition ${
                mode === 'classic'
                  ? 'border-[#ffb020] bg-[#212635] text-[#ffb020]'
                  : 'border-[#2b3144] bg-[#212635]/40 text-[#8a91a7]'
              }`}
            >
              Классика
            </button>
            <button
              onClick={() => { soundEffects.playTap(); onChangeMode('time'); }}
              className={`py-1.5 rounded-lg text-xs font-medium border transition ${
                mode === 'time'
                  ? 'border-[#4da3ff] bg-[#212635] text-[#4da3ff]'
                  : 'border-[#2b3144] bg-[#212635]/40 text-[#8a91a7]'
              }`}
            >
              На время
            </button>
            <button
              onClick={() => { soundEffects.playTap(); onChangeMode('bomb'); }}
              className={`py-1.5 rounded-lg text-xs font-medium border transition ${
                mode === 'bomb'
                  ? 'border-[#ff6b57] bg-[#212635] text-[#ff6b57]'
                  : 'border-[#2b3144] bg-[#212635]/40 text-[#8a91a7]'
              }`}
            >
              Бомбы
            </button>
          </div>

          {!isInstalled && (
            <button
              onClick={() => {
                soundEffects.playTap();
                onOpenInstall();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#212635] hover:bg-[#2b3144] text-[#ffb020] text-xs font-medium border border-[#2b3144] transition mt-2"
            >
              <Smartphone size={14} />
              <span>Установить как APK / Приложение</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

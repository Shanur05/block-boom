import React, { useState } from 'react';
import { Download, Smartphone, CheckCircle, Share2, PlusSquare, X, Copy, ExternalLink, Package, Check } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { soundEffects } from '../utils/audio';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [tab, setTab] = useState<'install' | 'apk'>('install');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-pre-prqm3n5rulvfssib2v76xd-101055585030.europe-west1.run.app';
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(currentUrl)}`;

  const handleInstallClick = async () => {
    soundEffects.playTap();
    const success = await install();
    if (success) {
      onClose();
    }
  };

  const handleCopyLink = () => {
    soundEffects.playTap();
    if (navigator.clipboard) {
      navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-2xl bg-[#161923] border border-[#2b3144] p-5 shadow-2xl text-[#eef0f6] relative max-h-[92vh] flex flex-col">
        <button
          onClick={() => {
            soundEffects.playTap();
            onClose();
          }}
          className="absolute top-4 right-4 text-[#8a91a7] hover:text-[#eef0f6] p-1 rounded-lg"
          aria-label="Закрыть"
        >
          <X size={20} />
        </button>

        <div className="flex items-center gap-3 mb-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#ffb020] to-[#ff6b57] p-2 flex items-center justify-center shadow-lg shrink-0">
            <Package className="text-black" size={24} />
          </div>
          <div>
            <h3 className="text-lg font-bold tracking-tight">Установка и APK</h3>
            <p className="text-xs text-[#8a91a7] font-mono">Android & iOS</p>
          </div>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-[#212635] text-xs font-medium mb-3 shrink-0">
          <button
            onClick={() => {
              soundEffects.playTap();
              setTab('install');
            }}
            className={`py-1.5 rounded-lg transition ${
              tab === 'install' ? 'bg-[#ffb020] text-black font-bold shadow' : 'text-[#8a91a7]'
            }`}
          >
            На телефон (1 клик)
          </button>
          <button
            onClick={() => {
              soundEffects.playTap();
              setTab('apk');
            }}
            className={`py-1.5 rounded-lg transition ${
              tab === 'apk' ? 'bg-[#ffb020] text-black font-bold shadow' : 'text-[#8a91a7]'
            }`}
          >
            Файл .APK
          </button>
        </div>

        <div className="overflow-y-auto pr-1 flex-1 space-y-3">
          {tab === 'install' && (
            <>
              {isInstalled ? (
                <div className="text-center py-6">
                  <CheckCircle className="mx-auto text-emerald-400 mb-3" size={44} />
                  <h4 className="font-bold text-base mb-1">Игра уже установлена!</h4>
                  <p className="text-xs text-[#8a91a7]">
                    Блок Бум работает на вашем устройстве как нативное приложение со 100% офлайн доступом.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="bg-[#212635] rounded-xl p-3 text-xs space-y-2 border border-[#2b3144]">
                    <div className="flex items-center gap-2 font-medium text-[#ffb020]">
                      <Smartphone size={16} />
                      <span>Преимущества WebAPK:</span>
                    </div>
                    <ul className="text-[#8a91a7] space-y-1 list-disc list-inside">
                      <li>Работает <span className="text-[#eef0f6]">полностью офлайн</span> без интернета</li>
                      <li>Полноэкранный режим без адресной строки</li>
                      <li>Настоящая иконка в списке приложений телефона</li>
                      <li>Не требует разрешения на «установку из неизвестных источников»</li>
                    </ul>
                  </div>

                  {/* Android / Desktop Direct Install */}
                  {isInstallable && (
                    <button
                      onClick={handleInstallClick}
                      className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-[#ffb020] text-black font-bold text-sm hover:brightness-110 active:scale-95 transition shadow-lg shadow-[#ffb020]/20"
                    >
                      <Download size={18} />
                      Установить прямо сейчас
                    </button>
                  )}

                  {/* Android manual guide */}
                  {!isInstallable && isAndroid && (
                    <div className="p-3 bg-[#212635]/60 rounded-xl border border-[#2b3144] text-xs text-[#8a91a7] space-y-2">
                      <p className="font-semibold text-[#eef0f6]">Инструкция для Android:</p>
                      <ol className="list-decimal list-inside space-y-1">
                        <li>Нажмите на <strong className="text-[#eef0f6]">меню Chrome (три точки ⋮)</strong> в правом верхнем углу</li>
                        <li>Выберите пункт <strong className="text-[#ffb020]">«Установить приложение»</strong></li>
                        <li>Android автоматически соберёт WebAPK и установит его на телефон</li>
                      </ol>
                    </div>
                  )}

                  {/* iOS Safari Guide */}
                  {isIOS && (
                    <div className="p-3 bg-[#212635]/60 rounded-xl border border-[#2b3144] text-xs text-[#8a91a7] space-y-2">
                      <p className="font-semibold text-[#eef0f6]">Инструкция для iPhone / iPad:</p>
                      <div className="flex items-start gap-2">
                        <Share2 className="text-[#4da3ff] shrink-0 mt-0.5" size={16} />
                        <span>1. Нажмите кнопку <strong>«Поделиться»</strong> в Safari</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <PlusSquare className="text-[#ffb020] shrink-0 mt-0.5" size={16} />
                        <span>2. Выберите <strong>«На экран «Домой»»</strong></span>
                      </div>
                    </div>
                  )}

                  {!isAndroid && !isIOS && !isInstallable && (
                    <div className="p-3 bg-[#212635]/60 rounded-xl border border-[#2b3144] text-xs text-[#8a91a7]">
                      Нажмите на иконку установки <strong className="text-[#ffb020]">⊕</strong> в адресной строке браузера, чтобы добавить игру на рабочий стол.
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {tab === 'apk' && (
            <div className="space-y-3 text-xs">
              <div className="bg-[#212635] p-3 rounded-xl border border-[#2b3144] space-y-2">
                <span className="font-bold text-[#ffb020] block text-sm">
                  Почему не нужен отдельный .APK файл:
                </span>
                <p className="text-[#8a91a7] leading-relaxed">
                  На Android игра устанавливается с помощью технологии <strong className="text-white">WebAPK</strong>. При нажатии на кнопку «Установить» сам телефон Android упаковывает игру в нативный APK, помещает её в список приложений и даёт полноценный значок на рабочем столе.
                </p>
              </div>

              {/* Direct ZIP Download */}
              <div className="p-3 bg-[#212635]/60 rounded-xl border border-[#2b3144] space-y-2">
                <p className="font-semibold text-[#eef0f6]">Скачать все файлы игры (ZIP-архив):</p>
                <p className="text-[#8a91a7]">
                  Полный комплект собранной игры (HTML, JS, стили, звуки и иконки) для локального запуска или сборки в Android Studio:
                </p>
                <a
                  href="/BlokBoom-game.zip"
                  download="BlokBoom-game.zip"
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#ffb020] text-black font-bold text-xs hover:brightness-110 active:scale-95 transition shadow"
                >
                  <Download size={14} />
                  <span>Скачать BlokBoom-game.zip (330 КБ)</span>
                </a>
              </div>

              {/* Step: Copy Link */}
              <div className="p-3 bg-[#212635]/60 rounded-xl border border-[#2b3144] space-y-2">
                <div className="font-semibold text-[#eef0f6] flex items-center justify-between">
                  <span>Ссылка на игру для телефона:</span>
                  <button
                    onClick={handleCopyLink}
                    className="flex items-center gap-1 text-[11px] text-[#ffb020] hover:underline"
                  >
                    {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copied ? 'Скопировано!' : 'Копировать'}</span>
                  </button>
                </div>
                <div className="p-2 rounded bg-black/40 font-mono text-[10px] break-all text-[#8a91a7]">
                  {currentUrl}
                </div>
              </div>
            </div>
          )}
        </div>

        <button
          onClick={() => {
            soundEffects.playTap();
            onClose();
          }}
          className="mt-3 w-full py-2.5 rounded-xl bg-[#212635] text-xs font-mono font-medium text-[#8a91a7] hover:text-[#eef0f6] border border-[#2b3144] transition shrink-0"
        >
          Вернуться к игре
        </button>
      </div>
    </div>
  );
};

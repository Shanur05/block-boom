import React, { useState, useEffect, useRef, useCallback } from 'react';
import { CellData, DragState, FloatingPop, GameMode, GameStats, Piece, UserSettings } from './types';
import {
  BOARD_SIZE,
  findFullLines,
  generatePieceSet,
  getLineCellIndices,
  putPiece,
  rotatePiece,
  anyFit,
} from './utils/gameLogic';
import { soundEffects } from './utils/audio';
import { haptics } from './utils/haptics';
import { Header } from './components/Header';
import { GameBoard } from './components/GameBoard';
import { PieceTray } from './components/PieceTray';
import { SettingsModal } from './components/SettingsModal';
import { InstallModal } from './components/InstallModal';
import { GameOverModal } from './components/GameOverModal';
import { PauseModal } from './components/PauseModal';
import { usePWAInstall } from './hooks/usePWAInstall';
import { WifiOff } from 'lucide-react';

const STORAGE_KEYS = {
  SETTINGS: 'blokboom_settings',
  STATS: 'blokboom_stats',
};

const DEFAULT_SETTINGS: UserSettings = {
  soundEnabled: true,
  vibrationEnabled: true,
  theme: 'neon',
};

const DEFAULT_STATS: GameStats = {
  gamesPlayed: 0,
  linesCleared: 0,
  highestStreak: 0,
  bestScores: {
    classic: 0,
    time: 0,
    bomb: 0,
  },
};

export default function App() {
  // PWA install hook
  const { isInstalled } = usePWAInstall();

  // Settings & Theme
  const [settings, setSettings] = useState<UserSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Game Stats & High Scores
  const [stats, setStats] = useState<GameStats>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STATS);
      return saved ? { ...DEFAULT_STATS, ...JSON.parse(saved) } : DEFAULT_STATS;
    } catch {
      return DEFAULT_STATS;
    }
  });

  // Game Mode
  const [mode, setMode] = useState<GameMode>('classic');

  // Board State
  const [grid, setGrid] = useState<(CellData | null)[]>(() =>
    Array(BOARD_SIZE * BOARD_SIZE).fill(null)
  );

  // Pieces in bottom tray (up to 3)
  const [pieces, setPieces] = useState<(Piece | null)[]>([]);

  // Score & Streaks
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [missedStreakMoves, setMissedStreakMoves] = useState<number>(0);
  const [startBestScore, setStartBestScore] = useState<number>(0);
  const [moveCount, setMoveCount] = useState<number>(0);

  // Time Mode State
  const [timeLeft, setTimeLeft] = useState<number>(90);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  // Boosters
  const [rotateUses, setRotateUses] = useState<number>(2);
  const [rerollUses, setRerollUses] = useState<number>(1);
  const [undoUses, setUndoUses] = useState<number>(1);
  const [isRotatingMode, setIsRotatingMode] = useState<boolean>(false);

  // Undo Snapshot
  const lastStateRef = useRef<{
    grid: (CellData | null)[];
    pieces: (Piece | null)[];
    score: number;
    streak: number;
  } | null>(null);

  // Visual Effects State
  const [boomingCells, setBoomingCells] = useState<Set<number>>(new Set());
  const [floatingPops, setFloatingPops] = useState<FloatingPop[]>([]);
  const [isShaking, setIsShaking] = useState<boolean>(false);

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isInstallOpen, setIsInstallOpen] = useState<boolean>(false);
  const [isPauseOpen, setIsPauseOpen] = useState<boolean>(false);
  const [gameOverReason, setGameOverReason] = useState<'no_moves' | 'bomb_exploded' | 'time_out' | null>(null);

  // Dragging State
  const [dragState, setDragState] = useState<DragState | null>(null);

  // Online / Offline tracking
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sync settings to sound/haptics and DOM theme attribute
  useEffect(() => {
    soundEffects.setEnabled(settings.soundEnabled);
    haptics.setEnabled(settings.vibrationEnabled);
    document.documentElement.setAttribute('data-theme', settings.theme);
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (_) {}
  }, [settings]);

  // Sync stats to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(stats));
    } catch (_) {}
  }, [stats]);

  // Add floating text animation
  const addFloatingPop = useCallback((text: string, x: number, y: number, isBig: boolean = false, color?: string) => {
    const id = 'pop-' + Math.random().toString(36).substring(2, 9);
    setFloatingPops((prev) => [...prev, { id, text, x, y, isBig, color }]);
    setTimeout(() => {
      setFloatingPops((prev) => prev.filter((p) => p.id !== id));
    }, 950);
  }, []);

  // Start / Reset Game
  const startNewGame = useCallback((newMode: GameMode = mode) => {
    const initialGrid = Array(BOARD_SIZE * BOARD_SIZE).fill(null);
    setGrid(initialGrid);
    setScore(0);
    setStreak(0);
    setMissedStreakMoves(0);
    setMoveCount(0);
    setRotateUses(2);
    setRerollUses(1);
    setUndoUses(1);
    setIsRotatingMode(false);
    lastStateRef.current = null;
    setBoomingCells(new Set());
    setFloatingPops([]);
    setGameOverReason(null);
    setIsPauseOpen(false);

    setStartBestScore(stats.bestScores[newMode] || 0);

    const initialPieces = generatePieceSet(initialGrid);
    setPieces(initialPieces);

    if (newMode === 'time') {
      setTimeLeft(90);
      setIsTimerRunning(true);
    } else {
      setIsTimerRunning(false);
    }
  }, [mode, stats.bestScores]);

  // Initial setup on mount
  useEffect(() => {
    startNewGame(mode);
  }, []);

  // Timer loop for Time Mode
  useEffect(() => {
    if (mode !== 'time' || !isTimerRunning || gameOverReason || isPauseOpen || isSettingsOpen) {
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          soundEffects.playGameOver();
          haptics.danger();
          setGameOverReason('time_out');
          return 0;
        }
        if (prev <= 10) {
          soundEffects.playBombTick();
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [mode, isTimerRunning, gameOverReason, isPauseOpen, isSettingsOpen]);

  // Check Game Over condition
  const checkGameOver = useCallback((currentGrid: (CellData | null)[], currentPieces: (Piece | null)[]) => {
    const hasRemainingMove = currentPieces.some((p) => p && anyFit(currentGrid, p.m));
    if (!hasRemainingMove) {
      soundEffects.playGameOver();
      haptics.danger();
      setGameOverReason('no_moves');

      // Update games played stats
      setStats((prev) => ({
        ...prev,
        gamesPlayed: prev.gamesPlayed + 1,
      }));
    }
  }, []);

  // Place piece handler
  const handlePlacePiece = useCallback(
    (pieceIndex: number, spot: { r: number; c: number }) => {
      const piece = pieces[pieceIndex];
      if (!piece) return;

      // Save state for Undo
      lastStateRef.current = {
        grid: [...grid],
        pieces: [...pieces],
        score,
        streak,
      };

      soundEffects.playDrop();
      haptics.medium();

      // Check for Bomb generation in Bomb mode
      let bombCoord: { r: number; c: number; count: number } | undefined = undefined;
      const nextMoveCount = moveCount + 1;
      setMoveCount(nextMoveCount);

      if (mode === 'bomb' && nextMoveCount % 4 === 0) {
        // Find filled cells in piece
        const filledCells: { r: number; c: number }[] = [];
        for (let y = 0; y < piece.h; y++) {
          for (let x = 0; x < piece.w; x++) {
            if (piece.m[y][x]) {
              filledCells.push({ r: spot.r + y, c: spot.c + x });
            }
          }
        }
        if (filledCells.length > 0) {
          const target = filledCells[Math.floor(Math.random() * filledCells.length)];
          bombCoord = { r: target.r, c: target.c, count: 9 };
        }
      }

      // Decrement existing bombs in Bomb mode
      let explodedBomb = false;
      const updatedGridWithBombs = grid.map((c) => {
        if (!c || !c.isBomb) return c;
        const nextCount = (c.bombCountdown ?? 1) - 1;
        if (nextCount <= 0) {
          explodedBomb = true;
        }
        return {
          ...c,
          bombCountdown: nextCount,
        };
      });

      if (explodedBomb) {
        soundEffects.playBombExplode();
        haptics.danger();
        setGameOverReason('bomb_exploded');
        return;
      }

      // Put piece onto the board
      let newGrid = putPiece(updatedGridWithBombs, piece, spot.r, spot.c, bombCoord);

      // Add base piece placement score
      const addedPoints = piece.n;
      let newScore = score + addedPoints;
      setScore(newScore);

      // Check best score update
      if (newScore > (stats.bestScores[mode] || 0)) {
        setStats((prev) => ({
          ...prev,
          bestScores: {
            ...prev.bestScores,
            [mode]: newScore,
          },
        }));
      }

      // Remove placed piece from tray
      const nextPieces = [...pieces];
      nextPieces[pieceIndex] = null;
      setPieces(nextPieces);

      // Measure placement point for popup text
      const boardEl = document.getElementById('game-board-container');
      const boardRect = boardEl ? boardEl.getBoundingClientRect() : { width: 340, height: 340 };
      const popupX = (boardRect.width / BOARD_SIZE) * (spot.c + piece.w / 2);
      const popupY = (boardRect.height / BOARD_SIZE) * (spot.r + piece.h / 2);

      // Check full lines
      const lines = findFullLines(newGrid);

      if (lines.total > 0) {
        const lineCellIndices = getLineCellIndices(lines);

        // Check if any bombs were defused
        let defusedCount = 0;
        lineCellIndices.forEach((idx) => {
          if (newGrid[idx]?.isBomb) {
            defusedCount++;
          }
        });

        // Trigger line boom animation
        setBoomingCells(new Set(lineCellIndices));
        soundEffects.playClearLine(lines.total);
        haptics.heavy();

        const nextStreak = streak + 1;
        setStreak(nextStreak);
        setMissedStreakMoves(0);

        // Update highest streak stat
        if (nextStreak > stats.highestStreak) {
          setStats((prev) => ({ ...prev, highestStreak: nextStreak }));
        }

        // Streak multiplier gain
        const gain = 10 * lines.total * lines.total * nextStreak;
        newScore += gain;

        if (defusedCount > 0) {
          newScore += defusedCount * 50;
        }

        setScore(newScore);

        // Best score sync
        if (newScore > (stats.bestScores[mode] || 0)) {
          setStats((prev) => ({
            ...prev,
            bestScores: {
              ...prev.bestScores,
              [mode]: newScore,
            },
          }));
        }

        // Add bonus time in Time mode
        if (mode === 'time') {
          const timeBonus = lines.total * 6;
          setTimeLeft((prev) => Math.min(120, prev + timeBonus));
          addFloatingPop(`+${timeBonus}с`, boardRect.width / 2, boardRect.height * 0.25, true, '#4da3ff');
        }

        // Sound combo chord
        setTimeout(() => {
          if (nextStreak >= 2) {
            soundEffects.playCombo(nextStreak);
          }
        }, 150);

        // Trigger board shake for multi-lines or high combos
        if (lines.total >= 2 || nextStreak >= 3) {
          setIsShaking(true);
          setTimeout(() => setIsShaking(false), 300);
        }

        // Delay for explosion animation to finish, then clear grid cells
        setTimeout(() => {
          setBoomingCells(new Set());
          const clearedGrid = [...newGrid];
          lineCellIndices.forEach((idx) => {
            clearedGrid[idx] = null;
          });
          setGrid(clearedGrid);

          // Update lines cleared stats
          setStats((prev) => ({
            ...prev,
            linesCleared: prev.linesCleared + lines.total,
          }));

          // Popups
          addFloatingPop(`+${gain}`, popupX, popupY, false);

          if (defusedCount > 0) {
            addFloatingPop('💣 ОБЕЗВРЕЖЕНА! +50', boardRect.width / 2, boardRect.height * 0.35, true, '#ff6b57');
          }

          if (nextStreak >= 2) {
            addFloatingPop(`Комбо ×${nextStreak}`, boardRect.width / 2, boardRect.height * 0.45, true, '#ffb020');
          } else if (lines.total >= 2) {
            const lineText = lines.total < 5 ? `${lines.total} линии` : `${lines.total} линий`;
            addFloatingPop(lineText, boardRect.width / 2, boardRect.height * 0.45, true, '#eef0f6');
          }

          // Full clear check
          const isEntireBoardClean = clearedGrid.every((c) => c === null);
          if (isEntireBoardClean) {
            const cleanBonus = 150;
            const cleanScore = newScore + cleanBonus;
            setScore(cleanScore);
            soundEffects.playCleanBoard();
            haptics.success();
            addFloatingPop('ЧИСТО! +150', boardRect.width / 2, boardRect.height * 0.6, true, '#8fd14f');
          }

          // Generate next set of pieces if all slots are empty
          let activePieces = nextPieces;
          if (nextPieces.every((p) => p === null)) {
            activePieces = generatePieceSet(clearedGrid);
            setPieces(activePieces);
          }

          checkGameOver(clearedGrid, activePieces);
        }, 320);
      } else {
        // No lines cleared this turn
        setGrid(newGrid);

        const nextMissed = missedStreakMoves + 1;
        setMissedStreakMoves(nextMissed);
        if (nextMissed >= 3) {
          setStreak(0);
        }

        // Generate next set if all slots are empty
        let activePieces = nextPieces;
        if (nextPieces.every((p) => p === null)) {
          activePieces = generatePieceSet(newGrid);
          setPieces(activePieces);
        }

        checkGameOver(newGrid, activePieces);
      }
    },
    [
      grid,
      pieces,
      score,
      streak,
      mode,
      moveCount,
      missedStreakMoves,
      stats.bestScores,
      stats.highestStreak,
      addFloatingPop,
      checkGameOver,
    ]
  );

  // Drag handlers
  const handleStartDrag = (index: number, piece: Piece, clientX: number, clientY: number) => {
    setDragState({
      pieceIndex: index,
      piece,
      startClientX: clientX,
      startClientY: clientY,
      currentClientX: clientX,
      currentClientY: clientY,
      hoverSpot: null,
    });
  };

  const handleUpdateDrag = (
    clientX: number,
    clientY: number,
    hoverSpot: { r: number; c: number } | null
  ) => {
    setDragState((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        currentClientX: clientX,
        currentClientY: clientY,
        hoverSpot,
      };
    });
  };

  const handleEndDrag = (placedSpot: { r: number; c: number } | null) => {
    if (!dragState) return;
    const { pieceIndex } = dragState;
    setDragState(null);

    if (placedSpot) {
      handlePlacePiece(pieceIndex, placedSpot);
    }
  };

  // Booster: Rotate
  const handleToggleRotateMode = () => {
    if (rotateUses <= 0) return;
    soundEffects.playTap();
    setIsRotatingMode((prev) => !prev);
  };

  const handleRotatePieceInTray = (index: number) => {
    if (rotateUses <= 0) return;
    const p = pieces[index];
    if (!p) return;

    const rotated = rotatePiece(p);
    const nextPieces = [...pieces];
    nextPieces[index] = rotated;
    setPieces(nextPieces);
    setRotateUses((u) => u - 1);
    setIsRotatingMode(false);
  };

  // Booster: Reroll
  const handleReroll = () => {
    if (rerollUses <= 0) return;
    soundEffects.playPowerUp();
    haptics.medium();
    const newPieces = generatePieceSet(grid);
    setPieces(newPieces);
    setRerollUses((u) => u - 1);
  };

  // Booster: Undo
  const handleUndo = () => {
    if (undoUses <= 0 || !lastStateRef.current) return;
    soundEffects.playPowerUp();
    haptics.medium();
    const snap = lastStateRef.current;
    setGrid(snap.grid);
    setPieces(snap.pieces);
    setScore(snap.score);
    setStreak(snap.streak);
    lastStateRef.current = null;
    setUndoUses((u) => u - 1);
  };

  const bestScoreForCurrentMode = stats.bestScores[mode] || 0;
  const isNewRecord = score > startBestScore && score === bestScoreForCurrentMode && score > 0;

  return (
    <div className="relative w-full h-[100dvh] flex flex-col items-center justify-between p-3 overflow-hidden select-none touch-none">
      {/* Offline Indicator */}
      {!isOnline && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-40 flex items-center gap-2 px-3 py-1 rounded-full bg-amber-600/90 text-white text-xs font-mono backdrop-blur-md shadow-lg animate-pulse">
          <WifiOff size={13} />
          <span>Офлайн режим (PWA/APK активен)</span>
        </div>
      )}

      {/* Header Bar */}
      <Header
        score={score}
        bestScore={bestScoreForCurrentMode}
        mode={mode}
        timeLeft={timeLeft}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenInstall={() => setIsInstallOpen(true)}
        onPause={() => setIsPauseOpen(true)}
        rotateUses={rotateUses}
        rerollUses={rerollUses}
        undoUses={undoUses}
        canUndo={Boolean(lastStateRef.current)}
        onRotateActive={handleToggleRotateMode}
        isRotating={isRotatingMode}
        onReroll={handleReroll}
        onUndo={handleUndo}
        streak={streak}
      />

      {/* Game Board (8x8) */}
      <GameBoard
        grid={grid}
        boomingCells={boomingCells}
        hoverSpot={dragState?.hoverSpot || null}
        draggedPiece={dragState?.piece || null}
        floatingPops={floatingPops}
        isShaking={isShaking}
      />

      {/* Piece Tray (3 Slots) */}
      <PieceTray
        pieces={pieces}
        grid={grid}
        isRotatingMode={isRotatingMode}
        onRotatePiece={handleRotatePieceInTray}
        onStartDrag={handleStartDrag}
        onUpdateDrag={handleUpdateDrag}
        onEndDrag={handleEndDrag}
        activeDragIndex={dragState?.pieceIndex ?? null}
      />

      {/* Hint footer */}
      <div className="text-[11px] font-mono text-[#8a91a7] text-center tracking-tight pb-1">
        {isRotatingMode ? (
          <span className="text-[#ffb020] font-bold animate-pulse">
            Нажмите на любую фигуру в лотке, чтобы повернуть её!
          </span>
        ) : (
          'Перетащите фигуру на поле. Заполните линию, чтобы взорвать её.'
        )}
      </div>

      {/* Floating Dragged Piece following finger / mouse */}
      {dragState && (
        <div
          className="fixed pointer-events-none z-50 filter drop-shadow-[0_12px_20px_rgba(0,0,0,0.65)]"
          style={{
            left: `${dragState.currentClientX}px`,
            top: `${dragState.currentClientY - 60}px`,
            transform: 'translate(-50%, -50%)',
          }}
        >
          <div
            className={`grid gap-1 t${dragState.piece.color}`}
            style={{
              gridTemplateColumns: `repeat(${dragState.piece.w}, minmax(0, 1fr))`,
            }}
          >
            {dragState.piece.m.map((row, rIdx) =>
              row.map((val, cIdx) => (
                <div
                  key={`${rIdx}-${cIdx}`}
                  className={`w-[36px] h-[36px] rounded-lg ${
                    val ? 'cell-filled scale-105' : 'opacity-0'
                  }`}
                />
              ))
            )}
          </div>
        </div>
      )}

      {/* Modals */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        stats={stats}
        onUpdateSettings={(newVals) => setSettings((s) => ({ ...s, ...newVals }))}
        onResetStats={() => {
          setStats(DEFAULT_STATS);
          setStartBestScore(0);
        }}
      />

      <InstallModal isOpen={isInstallOpen} onClose={() => setIsInstallOpen(false)} />

      <PauseModal
        isOpen={isPauseOpen}
        onResume={() => setIsPauseOpen(false)}
        onRestart={() => startNewGame(mode)}
        mode={mode}
        onChangeMode={(newMode) => {
          setMode(newMode);
          startNewGame(newMode);
        }}
        onOpenSettings={() => {
          setIsPauseOpen(false);
          setIsSettingsOpen(true);
        }}
        onOpenInstall={() => {
          setIsPauseOpen(false);
          setIsInstallOpen(true);
        }}
      />

      <GameOverModal
        isOpen={gameOverReason !== null}
        score={score}
        bestScore={bestScoreForCurrentMode}
        isNewRecord={isNewRecord}
        reason={gameOverReason || 'no_moves'}
        mode={mode}
        onRestart={() => startNewGame(mode)}
        onChangeMode={(newMode) => {
          setMode(newMode);
          startNewGame(newMode);
        }}
        onOpenInstall={() => setIsInstallOpen(true)}
        isInstalled={isInstalled}
      />
    </div>
  );
}
